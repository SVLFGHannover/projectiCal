from icalendar import Calendar, Event
import datetime
from dateutil import parser
c = Calendar()
e = Event()
name = "My cool event"
begin = '2021-02-21 15:00:00'
end = '2021-02-21 18:00:00'


print(newbegin.year)

print(test)
c.add("name", name)
e.add("dtstart", begin)
e.add("dtend", end)
c.add_component(e)

f = open('test.ics', 'wb')
f.write(c.to_ical())
f.close()